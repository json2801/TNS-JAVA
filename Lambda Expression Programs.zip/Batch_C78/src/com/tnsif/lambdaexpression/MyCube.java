package com.tnsif.lambdaexpression;

@FunctionalInterface
public interface MyCube {

	int getCube(int no);
	
}
