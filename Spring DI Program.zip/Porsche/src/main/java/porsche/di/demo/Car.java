package porsche.di.demo;

public class Car {

	private Wheel wheelObj; //Reference variable of wheel class or wheel object
	
	public Wheel getWheelObj() {
		return wheelObj;
	}
	
	
	public void setWheelObj(Wheel wheelObj) {
		this.wheelObj = wheelObj;
	}
}
