package com.tnsif.oopsconcept;

public class Executor {

	public static void main(String[] args) {

		EncapsulationDemo ed = new EncapsulationDemo();
		ed.setName("MS Dhoni");
		ed.setAge(43);
		ed.setJersyNo(7);
		System.out.println(ed);

		
		 Executor e = new Executor(); System.out.println(e);
		 

	}

}
